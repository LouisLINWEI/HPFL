import torchvision

def DenseNet121_ImageNet():
    return torchvision.models.densenet121()
