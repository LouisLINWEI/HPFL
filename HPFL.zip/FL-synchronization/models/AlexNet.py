import torchvision

def AlexNet_ImageNet():
    return torchvision.models.alexnet()
